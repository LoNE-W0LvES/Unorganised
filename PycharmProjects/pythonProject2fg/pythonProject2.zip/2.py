import math
a = 0.306
Ts = 6.96e8
Rs = 6.96e6
D = 1.496e11
sigma = 1.2
Tp = Ts * math.sqrt((Rs * math.sqrt((1 - a) / sigma)) / (2 * D))
print(f"The value of Tp is: {Tp}")
