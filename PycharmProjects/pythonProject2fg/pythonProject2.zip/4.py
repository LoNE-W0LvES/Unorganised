saddle_points = []
min_row = 0
def findSaddlePoint(mat, n):
    for i in range(n):
        min_row = mat[i][0]
        col_ind = 0
        for j in range(1, n):
            if min_row > mat[i][j]:
                min_row = mat[i][j]
                col_ind = j

        for i in range(len(mat)):
            row_min = min(mat[i])
            for j in range(len(mat[i])):
                column_max = max(mat[k][j] for k in range(len(mat)))
                if mat[i][j] == row_min and mat[i][j] == column_max:
                    saddle_points.append((i, j))
        k = 0
        for k in range(n):
            if min_row < mat[k][col_ind]:
                break
            k += 1

        if k == n:
            return min_row, saddle_points

# Driver method
if __name__ == '__main__':

    n = int(input("Enter the number of rows and columns (n): "))
    mat = []

    print("Enter the elements of the matrix:")
    for x in range(n):
        row = input().split(' ')
        n_r = [int(i) for i in row]
        mat.append(n_r)

    for m, n in findSaddlePoint(mat, n):
        print(m)
        print(n)

    # if not findSaddlePoint(mat, n):
    #     print("No Saddle Point")
    # else:
    #     print("Value of Saddle Point ", min_row)
    #     for m, n in findSaddlePoint(mat, n):
    #         print(m)
    #         print(n)
            # print(f"({point[0] + 1}, {point[1] + 1})")

