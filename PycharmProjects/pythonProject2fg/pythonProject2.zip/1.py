from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas


def is_palindrome(input_str):
    input_str = str(input_str).replace(" ", "").lower()
    return input_str == input_str[::-1]


user_input = input("Enter a string or number: ")

result = ''

if is_palindrome(user_input):
    result = f"'{user_input}' is a palindrome."
else:
    result = f"'{user_input}' is not a palindrome."

code = open("1.py", "r").read()
code_x = open("1.py", "r").readlines()
code_x.append("Palindrome Check Result:")
code_x.append(result)

ff = 0
open("palindrome_checker_code.txt", "w").write(code + '\nPalindrome Check Result:' + result)
c = canvas.Canvas("palindrome_result.pdf", pagesize=letter)
c.setFont("Helvetica", 12)

while ff != len(code_x) - 1:
    for i in range(700, 100, -20):
        c.drawString(100, i, code_x[ff].replace('\n', ''))
        if ff == len(code_x) - 1:
            break
        ff += 1
    c.showPage()
c.save()

print(result)
print("\nOutput saved to 'palindrome_result.pdf'\ncode saved to 'palindrome_checker_code.txt'")
